package Interfaces;

public interface IBranchService {

	public abstract void processOrder();
	public abstract void displayNewOrder();
	public abstract void viewDetails();
}
