package Interfaces;

public interface IPayment {
    public abstract void processPayment();
}
