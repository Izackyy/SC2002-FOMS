package Controllers;


public class StaffController extends EmployeeController{ //inheritence

	public void start()
	{
		System.out.println("Welcome to Staff Actions :)");
	}

	
	public void processOrder() {
		// TODO Auto-generated method stub
		
	}
}
