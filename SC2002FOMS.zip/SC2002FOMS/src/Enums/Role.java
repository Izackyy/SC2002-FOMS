package Enums;

public enum Role {
	
	S, //staff
	M, //manager
	A  //admin

}
