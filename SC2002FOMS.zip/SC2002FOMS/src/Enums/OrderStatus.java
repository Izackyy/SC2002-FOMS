package Enums;

public enum OrderStatus {
	
	PROCESSING,
	
	READY_TO_PICKUP,
	
	CANCELLED,
	
	COLLECTED

}
