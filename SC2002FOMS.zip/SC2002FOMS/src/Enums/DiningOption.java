package Enums;

public enum DiningOption {
	
	DINE_IN,
	
	TAKEAWAY;

}
