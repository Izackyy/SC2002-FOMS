package Services;

import java.io.IOException;
import java.util.ArrayList;

import Stores.Staff;
import Stores.StaffTextDB;

public class StaffDisplay {
	
	public static void printStaffList() //for admin to call
	  {
		  String filename = "staff.txt" ;
			try {
				// read file containing staff records.
				ArrayList al = StaffTextDB.readStaff(filename) ;
				for (int i = 0 ; i < al.size() ; i++) {
						Staff staff = (Staff)al.get(i);
						System.out.println("Name: " + staff.getName() + ", LoginID:" + staff.getLoginID() + ", Role:" + staff.getRole() + ", Gender:" + staff.getGender() + ", Age:" + staff.getAge() + ", Branch:" + staff.getBranch());
				}
				
			}catch (IOException e) {
				System.out.println("IOException > " + e.getMessage());
			}
	  	}
	  
	  public static void printStaffList(String branch) //overload to call branch staff list
	  {
		  System.out.println("Staff List @" + branch);
		  String filename = "staff.txt" ;
			try {
				// read file containing staff records.
				ArrayList al = StaffTextDB.readStaff(filename) ;
				for (int i = 0 ; i < al.size() ; i++) { 
						Staff staff = (Staff)al.get(i);
						if (staff.getBranch().equals(branch))
						{
							System.out.println("Name: " + staff.getName() + ", LoginID: " + staff.getLoginID() + ", Role: " + staff.getRole() + ", Gender: " + staff.getGender() + ", Age: " + staff.getAge() + ", Branch: " + staff.getBranch());
						}
				}
				
			}catch (IOException e) {
				System.out.println("IOException > " + e.getMessage());
			}
	  	}

}
